print('Bienvenue dans le cours d\'analyse de données en géographie !')

import numpy
import pandas as pd
import geopandas as gdp

data = pd.DataFrame({'A': [1, 2, 3]})
print(data)
